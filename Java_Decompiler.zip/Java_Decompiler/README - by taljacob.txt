GUIDE:

NOTE:
make sure there are two folders already made:
"classesFolder", "decompileFolder".

place ALL your desired ".class / .jar" files to de-compress inside the "classesFolder".

run the "decompile.bat" file - FOR WINDOWS.
run the "decompile.sh" file - FOR UNIX.

ALL your desired de-compiled files are placed in the "decompileFolder".

ENJOY!
