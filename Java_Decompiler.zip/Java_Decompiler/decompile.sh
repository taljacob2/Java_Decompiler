#!/bin/bash

java -cp java-decompiler.jar org.jetbrains.java.decompiler.main.decompiler.ConsoleDecompiler -dgs=true ./classesFolder ./decompileFolder

